"use strict";

import * as currentModule from "./popup.js";
import * as common from "./common.js";
import PageEvent from "./modules/PageEvent.js";

export const name = "popup";

const state = {
	tabId: null
};

function clickTitle(e) {
	common.switchToTabAsync(e.target.dataset.tabId);
}

async function loadTabStateAsync() {
	state.tabState = await common.sendMessageAsync({
		scope: "tab",
		id: state.tabId
	});	
}
async function loadEventsAsync() {
	// get events from background.js
	const currentEvents = await common.sendMessageAsync({ scope: common.name, command: common.getEvents.name });
	common.setEvents(currentEvents, PageEvent.fromObj);

	const container = globalThis.document.getElementById("eventsContainer");
	while (container.children.length) {
		container.children[0].remove();
	}

	for (const currentEvent of common.state.currentEvents) {
		const row = globalThis.document.createElement("div");
		row.className = "row";
		row.dataset.tabId = currentEvent.tabId;
		const column1 = globalThis.document.createElement("div");
		column1.className = "col-12 font-weight-bold";
		const titleLink = globalThis.document.createElement("a");
		titleLink.className = "text-decoration-none text-reset";
		titleLink.href = "#";
		titleLink.innerText = currentEvent.getTitle();
		titleLink.dataset.tabId = currentEvent.tabId;
		titleLink.addEventListener("click", clickTitle);
		column1.appendChild(titleLink);
		const column2 = globalThis.document.createElement("div");
		column2.className = "col-12";

		row.appendChild(column1);
		row.appendChild(column2);
		container.appendChild(row);

		if (currentEvent.completed) {
			const icon = globalThis.document.createElement("img");
			icon.className = "mr-2";
			icon.src = "../Icons/icon" + (currentEvent.icon ? "-" + currentEvent.icon : "") + ".png";
			icon.width = icon.height = 30;
			column1.insertBefore(icon, column1.firstChild);
			column2.remove();
		} else {
			const progressBarContainer = globalThis.document.createElement("div");
			progressBarContainer.className = "progress";
			const progressBar = globalThis.document.createElement("div");

			progressBar.className = "progress-bar progress-bar-striped progress-bar-animated";
			progressBar.style.width = (currentEvent.progress || 100) + "%";

			progressBarContainer.appendChild(progressBar);
			column2.appendChild(progressBarContainer);
		}
	}

	if (common.state.currentEvents.length === 0) {
		const message = globalThis.document.createElement("div");
		message.className = "text";
		message.innerText = "No event";
		container.appendChild(message);
	}
}

function automationLogger(type, message) {
	const timestampElement = globalThis.document.createElement("div");
	timestampElement.className = "px-2 text-success log-line-timstamp";
	timestampElement.innerText = new Date().toLocaleTimeString();

	const messageElement = globalThis.document.createElement("div");
	messageElement.className = "text-" + type;
	messageElement.innerText = message;

	const rowElement = globalThis.document.createElement("div");
	rowElement.className = "d-flex log-line";
	rowElement.appendChild(timestampElement);
	rowElement.appendChild(messageElement);

	const logContainer = document.getElementById("automationLog");
	logContainer.appendChild(rowElement);
	logContainer.scrollTop = logContainer.scrollHeight;
}

function bindAutomationOnClick(element, automationTask) {
	element.addEventListener("click", async () => {
		document.getElementById("automationLogTitle").classList.remove("d-none");
		const logContainer = document.getElementById("automationLog");
		logContainer.classList.remove("d-none");
		while (logContainer.children.length) {
			logContainer.children[0].remove();
		}

		const options = await common.getOptionsAsync();

		await common.sendMessageAsync({
			scope: "tab",
			id: state.tabId,
			command: "update",
			arguments: [{
				id: state.tabId,
				isRunningAutomationTask: true
			}]
		})

		await automationTask.executeAsync(state.tabId, options.Automations, automationLogger);
		
		await common.sendMessageAsync({
			scope: "tab",
			id: state.tabId,
			command: "update",
			arguments: [{
				id: state.tabId,
				isRunningAutomationTask: false
			}]
		})
	});
}

function appendAutomationDropdown(container, automationType, automationTasks) {
	const header = globalThis.document.createElement("li");
	header.className = "list-group-item list-group-item-dark font-weight-bold";
	header.innerText = automationType;
	container.appendChild(header);

	for (const automationTask of automationTasks) {
		const dropdownItem = globalThis.document.createElement("li");
		dropdownItem.className = "list-group-item d-flex justify-content-between align-items-center py-0 pr-0";
		dropdownItem.appendChild(globalThis.document.createTextNode(automationTask.name));
		const runButton = globalThis.document.createElement("button");
		runButton.className = "btn btn-primary btn-md rounded-0 px-3 float-right";
		runButton.innerText = "Run";
		dropdownItem.appendChild(runButton);

		bindAutomationOnClick(runButton, automationTask);
		container.appendChild(dropdownItem);
	}
}

async function loadAvailableAutomationsAsync() {
	const container = globalThis.document.getElementById("automationsContainer");
	if (container.classList.contains("d-none")) {
		container.classList.remove("d-none");
		while (container.children.length) {
			container.children[0].remove();
		}

		const logContainerTitle = globalThis.document.createElement("li");
		logContainerTitle.className = "list-group-item list-group-item-primary font-weight-bold d-none";
		logContainerTitle.innerText = "Log";
		logContainerTitle.id = "automationLogTitle";

		const logContainer = globalThis.document.createElement("li");
		logContainer.className = "list-group-item d-none";
		logContainer.id = "automationLog";

		container.appendChild(logContainerTitle);
		container.appendChild(logContainer);
	} else {
		container.classList.add("d-none");
		return;
	}

	const automationTaskList = [];
	if (state.tabState.isSitecoreApplication || state.tabState.isSitecoreIdentityServer) {
		const SitecoreAutomation = await import("./features/SitecoreAutomation.js");

		if (state.tabState.isSitecoreApplication) {
			automationTaskList.push(...(await SitecoreAutomation.GetSitecoreApplicationAutomations(state.tabId)));
		}

		if (state.tabState.isSitecoreIdentityServer) {
			automationTaskList.push(...(await SitecoreAutomation.GetSitecoreIdentityServerAutomations(state.tabId)));
		}
	}

	if (state.tabState.isCommerceApplication) {
		const CommerceAutomation = await import("./features/CommerceAutomation.js");
		automationTaskList.push(...(await CommerceAutomation.GetCommerceAutomations(state.tabId)));
	}

	if (automationTaskList.length) {
		const automationTypes = {};
		automationTaskList.forEach(a => {
			if (!automationTypes.hasOwnProperty(a.type)) {
				automationTypes[a.type] = [];
			}
			if (automationTypes[a.type].indexOf(a) === -1) {
				automationTypes[a.type].push(a);
			}
		});

		for (const automationType in automationTypes) {
			appendAutomationDropdown(container, automationType, automationTypes[automationType]);
		}
	} else {
		const emptyElement = document.createElement("li");
		emptyElement.className = "list-group-item";
		emptyElement.innerText = "No Automation available";
		container.appendChild(emptyElement);
	}
}

function bypassCertSecurity() {
	common.sendMessageAsync({ command: "bypassCertificateSecurity", arguments: [state.tabId] });
}

async function messageListenerAsync(message, sender, sendResponse) {
	if (message.currentEvent) {
		await loadEventsAsync();
	}

	if (message.scope === "tab" && message.command === "update" && message.arguments[0].id === state.tabId) {
		await loadTabStateAsync();
	}
}

export async function initializeAsync() {
	common.state.currentPage = currentModule.name;
	common.addElementOnClick("automationsButton", loadAvailableAutomationsAsync);
	common.addElementOnClick("bypassCertSecurityButton", bypassCertSecurity);
	common.addElementOnClick("optionsButton", common.goToOptionsPage);
	globalThis.browser.runtime.onMessage.addListener(messageListenerAsync);

	// get current tab id
	const tabId = await common.getActiveTabAsync();
	state.tabId = tabId;
		
	// get current tab state
	await loadTabStateAsync();

	if (state.tabState.invalidCert) {
		bypassCertSecurity();
		//globalThis.document.getElementById("bypassCertSecurityButton").classList.remove("d-none");
	} else {
		loadEventsAsync();
	}
}

globalThis.debugScript = () => {
    console.log("debug");
};

globalThis.document.addEventListener("DOMContentLoaded", currentModule.initializeAsync);