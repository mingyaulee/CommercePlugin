export default {
	type: Object,
	name: "Root",
	value: {
		Common: {
			type: Object,
			name: "Common Options",
			value: {
				Url: {
					type: String,
					name: "TFS Url (Regex)",
					value: "https?://tfs4dk1(\\.dk\\.sitecore\\.net)?/"
				},
				NodeServerUrl: {
					type: String,
					name: "Node Server Url",
					value: "http://localhost:8088"
				}
			}
		},
		Automations: {
			type: Object,
			name: "Automation Options",
			value: {
				Sitecore: {
					type: Object,
					name: "Sitecore Automation",
					value: {
						Login: {
							type: Object,
							name: "Sitecore Login",
							value: {
								Username: {
									type: String,
									name: "Username",
									value: "admin"
								},
								Password: {
									type: String,
									name: "Password",
									value: "b",
								},
								Azure: {
									type: Object,
									name: "Azure instance",
									value: {
										UsernameAzure: {
											type: String,
											name: "Username",
											value: "admin"
										},
										PasswordAzure: {
											type: String,
											name: "Password",
											value: "Password12345",
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}