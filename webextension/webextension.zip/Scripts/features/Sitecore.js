"use strict";

import * as common from "../common.js";

const state = {
    handledHosts: [],
    redirectedHosts: []
};

function addHandledHost(host) {
    state.handledHosts.push(host);
    globalThis.setTimeout(() => state.handledHosts = state.handledHosts.filter(x => x !== host), 60000);
}

function addRedirectedHost(host) {
    state.redirectedHosts.push(host);
    globalThis.setTimeout(() => state.redirectedHosts = state.redirectedHosts.filter(x => x !== host), 60000);
}

async function addIpAddressToHostFileAsync(nodeServerUrl, host) {
    if (state.handledHosts.indexOf(host) === -1) {
        addHandledHost(host);

        // add identity server to the host file
        const result = await fetch(nodeServerUrl + "?action=resolveHostName&hostName=" + encodeURIComponent(host));
        return result.json();
    }
}

async function handleIPAddressMappingErrorAsync(background, tabId, host, redirectUrl) {
    // Identity Server IP address is not mapped in the host file
    const notificationId = background.sendNotification({
        icon: "info",
        message: "Adding IP address to host file"
    });

    const result = await addIpAddressToHostFileAsync(background.state.options.nodeServerUrl, host);

    if (result.output) {
        background.sendNotification({
            id: notificationId,
            update: true,
            icon: "success",
            message: "Added IP address to host file, redirecting to " + redirectUrl
        });
        common.redirectTabToUrlAsync(tabId, redirectUrl);
    } else {
        background.sendNotification({
            id: notificationId,
            update: true,
            icon: "fail",
            message: "Failed to add IP address to host file"
        });
    }
}

function handleAbortedFormSubmission(background, tabId, host, redirectUrl) {
    // Form submission to Identity Server does not work upon reloading
    if (state.redirectedHosts.indexOf(host) === -1) {
        background.sendNotification({
            icon: "info",
            message: "Redirecting to " + redirectUrl
        });

        addRedirectedHost(host);
        common.redirectTabToUrlAsync(tabId, redirectUrl);
    }
}

export function HandlePageLoadError(details, background) {
    const url = details.url.toLowerCase();
    const host = url.substring(url.indexOf("//") + 2, url.indexOf("-identityserver"));
    const redirectUrl = "https://" + host + "/sitecore";

    if (host.indexOf("/") === -1) {
        const ipAddressErrors = ["net::ERR_CONNECTION_REFUSED", "net::ERR_CONNECTION_RESET", "net::ERR_NAME_NOT_RESOLVED", "net::ERR_CONNECTION_TIMED_OUT"];
        if (ipAddressErrors.indexOf(details.error) > -1) {
            handleIPAddressMappingErrorAsync(background, details.tabId, host, redirectUrl);
        } else if (details.error === "net::ERR_ABORTED") {
            handleAbortedFormSubmission(background, details.tabId, host, redirectUrl);
        }
    }
}