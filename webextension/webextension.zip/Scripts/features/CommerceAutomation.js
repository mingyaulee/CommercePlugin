"use strict";

import * as common from "../common.js";
import * as SitecoreAutomation from "../features/SitecoreAutomation.js";
import { HelperFunctions } from "../helpers/AutomationHelper.js";
import AutomationTask from "../modules/AutomationTask.js";

const AutomationType = "Commerce";

const FillInDeliveryInformation = new AutomationTask(AutomationType, "Fill in delivery information", async context => {
    await context.helper.executeScriptAsync(`
        const component = document.querySelector(".cxa-checkoutdelivery-component");
        if (component) {
            const data = ko.dataFor(component);
            data.selectedShippingOption(1);

            data.shippingAddress().name("Testing Customer");
            data.shippingAddress().city("California");
            data.shippingAddress().country("US");
            data.shippingAddress().state("CA");
            data.shippingAddress().address1("123 Queen Street");
            data.shippingAddress().zipPostalCode("2022");

            if (data.shippingMethods().length === 0) {
                data.getShippingMethods();
                await helper.waitForConditionAsync(() => data.shippingMethods().length > 0);
            }
            data.shippingMethod(data.shippingMethods()[0]);
        }
    `, { helpers: [HelperFunctions] });
    context.end(true);
});

const FillInBillingInformation = new AutomationTask(AutomationType, "Fill in billing information", async context => {
    await context.helper.executeScriptAsync(`
        const component = document.querySelector(".cxa-checkoutbilling-component");
        if (component) {
            const data = ko.dataFor(component);
            data.billingEmail("test@test.com");
            data.billingConfirmEmail("test@test.com");

            if (jQuery(".apply-credit-card-toggle").is(".ccpayment.open") === false) {
                jQuery(".apply-credit-card-toggle").trigger("click");
            }
            data.selectedBillingAddress("UseShipping");
        }
    `);

    await context.helper.waitForConditionAsync(`document.getElementById("braintree-dropin-frame") !== null`);
    await context.helper.executeScriptAsync(`
        await helper.waitForConditionAsync(() => document.body.classList.contains("is-loading") === false);
        jQuery("#credit-card-number").val("4111 1111 1111 1111").trigger("change");
        const expiryYear = (new Date().getFullYear() + 1).toString().substring(2);
        jQuery("#expiration").val("11 / " + expiryYear).trigger("change");
    `, { frameId: "#braintree-dropin-frame", helpers: [HelperFunctions] });

    await context.helper.executeScriptAsync(`
        jQuery(".validate-payment-btn").trigger("click");
    `);

    context.end(true);
});

export async function GetCommerceAutomations(tabId) {
    const automations = [];

    const tabInfo = await common.getTabAsync(tabId);
    const url = tabInfo.url.toLowerCase();
    if (url.indexOf("/checkout/delivery") > -1) {
        automations.push(FillInDeliveryInformation);
    }

    if (url.indexOf("/checkout/billing") > -1) {
        automations.push(FillInBillingInformation);
    }

    automations.push(SitecoreAutomation.LoginToSitecore);
    automations.push(SitecoreAutomation.LaunchContentEditor);

    if (!(await SitecoreAutomation.IsContentEditorPageAsync(tabId))) {
        automations.push(SitecoreAutomation.SwitchOffResourceOptimiser);
    }

    automations.push(new AutomationTask("Test", "Debug", async context => {
        globalThis.helper = context.helper;
        await context.helper.executeScriptAsync(`
            window.helper = helper;
            window.scHelper = scHelper;
        `, { helpers: [HelperFunctions, SitecoreAutomation.ScHelperFunctions] });
        context.end(true);
    }));

    return automations;
}