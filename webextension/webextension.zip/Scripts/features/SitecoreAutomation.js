"use strict";

import * as common from "../common.js";
import { HelperFunctions } from "../helpers/AutomationHelper.js";
import AutomationTask from "../modules/AutomationTask.js";

const AutomationType = "Sitecore";

/**
 * Sitecore helper function for script injection
 */
export function ScHelperFunctions() {
    return `const scHelper = (function () {
        const clickButton = (buttonElement) => {
            if (buttonElement.prop("onclick")) {
                const offset = buttonElement.offset();
                const x = offset.left;
                const y = offset.top;
                const clickEvent = {
                    clientX: x,
                    clientY: y,
                    isDefaultPrevented: false,
                    stopPropagation: () => {},
                    preventDefault: () => { clickEvent.isDefaultPrevented = true; }
                };
                scForm.lastEvent = clickEvent;
                buttonElement[0].onclick(clickEvent);
            } else {
                buttonElement.trigger("click");
            }
        };
        const waitForAjaxAsync = () => helper.waitForConditionAsync(() => {
            let ajaxCount = 0;
            if (window.jQuery) {
                ajaxCount += window.jQuery.active;
            }
            if (window.scForm && window.scForm.requests) {
                ajaxCount += scForm.requests.length;
            }
            if (window.Ajax) {
                ajaxCount += Ajax.activeRequestCount;
            }
            return ajaxCount === 0;
        }, { delayMs: 500 });
        const waitForPopupAsync = () => helper.waitForConditionAsync(() => {
            const popupFrame = document.getElementById("jqueryModalDialogsFrame");
            if (popupFrame) {
                const popups = popupFrame.contentWindow.document.getElementsByTagName("iframe");
                for (const popup of popups) {
                    if (popup.contentWindow.document.readyState !== "complete") {
                        return false;
                    }
                }
            }
            return true;
        }, { delayMs: 500 });
        return {
            waitForAjaxAsync: waitForAjaxAsync,
            waitForPopupAsync: waitForPopupAsync,
            contentEditor: {
                ribbon: {
                    getTab: (tabName) => {
                        tabName = tabName.toUpperCase();
                        const tabElement = jQuery("#ContentEditorForm #RibbonPanel .scRibbonNavigatorButtonsGroupButtons")
                            .children()
                            .filter((index, tabElement) => jQuery(tabElement).text().toUpperCase() === tabName);

                        if (tabElement.length === 0) {
                            throw new Error("Ribbon tab is not found (" + tabName + ")");
                        }

                        if (tabElement.hasClass("scRibbonNavigatorButtonsActive") === false) {
                            tabElement.trigger("click");
                        }

                        return {
                            tabElement: tabElement,
                            getButton: (buttonName) => {
                                buttonName = buttonName.toUpperCase();
                                const buttonElement = jQuery("#ContentEditorForm #RibbonPanel .scRibbonToolbarStrip:visible .chunk > .panel")
                                    .find(".scRibbonToolbarLargeButton, .scRibbonToolbarSmallButton, .scRibbonToolbarLargeGalleryButton, .scRibbonToolbarSmallGalleryButton, .scRibbonToolbarLargeComboButton, .scRibbonToolbarSmallComboButton")
                                    .filter((index, buttonElement) => jQuery(buttonElement).find(".header").text().toUpperCase() === buttonName);

                                if (buttonElement.length === 0) {
                                    throw new Error("Button is not found in ribbon tab (" + buttonName + ")");
                                }

                                const button = {
                                    buttonElement: buttonElement,
                                    clickAsync: () => {
                                        if (buttonElement.is("a") === false) {
                                            clickButton(buttonElement.find("a:first"));
                                        } else {
                                            clickButton(buttonElement);
                                        }
                                        return waitForAjaxAsync();
                                    }
                                };

                                if (buttonElement.is(".scRibbonToolbarLargeGalleryButton, .scRibbonToolbarSmallGalleryButton, .scRibbonToolbarLargeComboButton, .scRibbonToolbarSmallComboButton")) {
                                    button.expandAsync = async () => {
                                        const expandButton = buttonElement.is(".scRibbonToolbarLargeComboButton, .scRibbonToolbarSmallComboButton") ? buttonElement.find(".scRibbonToolbarLargeComboButtonBottom, .scRibbonToolbarSmallComboButtonRight") : buttonElement;
                                        clickButton(expandButton);
                                        await waitForAjaxAsync();

                                        const containerElement = jQuery("div[data-openerid='" + expandButton.prop("id") + "'], iframe#" + expandButton.prop("id") + "_frame");
                                        const expandedButton = {
                                            containerElement: containerElement
                                        };

                                        if (containerElement.is("div.scPopup")) {
                                            expandedButton.getButton = (buttonName) => {
                                                buttonName = buttonName.toUpperCase();
                                                const buttonElement = containerElement.find("tr").filter((index, buttonElement) => jQuery(buttonElement).children("td.scMenuItemCaption").text().toUpperCase() === buttonName);

                                                if (buttonElement.length === 0) {
                                                    throw new Error("Button is not found in the popup (" + buttonName + ")");
                                                }

                                                return {
                                                    buttonElement: buttonElement,
                                                    clickAsync: () => {
                                                        clickButton(buttonElement);
                                                        return waitForAjaxAsync();
                                                    }
                                                };
                                            };
                                        }
                                        return expandedButton;
                                    }
                                }

                                return button;
                            }
                        };
                    }
                },
                getContentTabAsync: async () => {
                    const contentTabElement = jQuery("#ContentEditorForm #ContentEditor #EditorTabs")
                        .children()
                        .filter((index, tab) => jQuery(tab).text().toUpperCase() === "CONTENT");

                    if (contentTabElement.length === 0) {
                        throw new Error("Content tab is not found in Content Editor");
                    }

                    if (contentTabElement.find(".scEditorTabHeaderActive").length === 0) {
                        contentTabElement.trigger("click");
                        await waitForAjaxAsync();
                    }

                    contentTabId = contentTabElement.prop("id");
                    const getContentFrameElement = () => jQuery("#ContentEditorForm #ContentEditor #EditorFrames #F" + contentTabId.substring(1));
                    return {
                        contentTabElement: contentTabElement,
                        get contentFrameElement() {
                            return getContentFrameElement();
                        },
                        getSectionAsync: async (sectionName) => {
                            sectionName = sectionName.toUpperCase();
                            const getSectionElement = () => getContentFrameElement()
                                .find(".scEditorSectionCaptionExpanded, .scEditorSectionCaptionCollapsed")
                                .filter((index, sectionElement) => jQuery(sectionElement).text().toUpperCase() === sectionName);
                            
                            const sectionElement = getSectionElement();

                            if (sectionElement.length === 0) {
                                throw new Error("Section is not found in Content Tab (" + sectionName + ")");
                            }

                            if (sectionElement.hasClass("scEditorSectionCaptionExpanded") === false) {
                                sectionElement.trigger("click");
                                await waitForAjaxAsync();
                            }

                            return {
                                get sectionHeaderElement() {
                                    return getSectionElement();
                                },
                                get sectionFieldsElement() {
                                    return getSectionElement().next();
                                },
                                getField: (fieldName) => {
                                    fieldName = fieldName.toUpperCase();
                                    const fieldElement = jQuery(getSectionElement().next())
                                        .find(".scEditorSectionPanelCell .scEditorFieldMarkerInputCell")
                                        .filter((index, fieldElement) => jQuery(fieldElement).children(".scEditorFieldLabel").contents().first().text().toUpperCase() === fieldName);

                                    if (fieldElement.length === 0) {
                                        throw new Error("Field is not found in section (" + fieldName + ")");
                                    }

                                    const getFieldValueElement = () => {
                                        return fieldElement.find("input.scContentControl, input.scComboboxEdit, select.scCombobox, select.scContentControlMultilistBox");
                                    };

                                    const field = {
                                        fieldElement: fieldElement,
                                        get fieldValueElement() {
                                            return getFieldValueElement();
                                        }
                                    }

                                    const fieldValueElement = field.fieldValueElement;
                                    if (fieldValueElement.is("input")) {
                                        field.getValue = () => getFieldValueElement().val();
                                        field.setValue = (value) => getFieldValueElement().val(value);
                                    } else if (fieldValueElement.is("select.scCombobox")) {
                                        field.getSelectedValueElement = () => getFieldValueElement().find("option[selected]");
                                        field.getSelectedValue = () => field.getSelectedValueElement().prop("value");
                                        field.getSelectedText = () => field.getSelectedValueElement().text();
                                        field.setSelectedValue = (value) => getFieldValueElement().val(value);
                                        field.setSelectedText = (value) => {
                                            value = value.toUpperCase();
                                            const valueElement = getFieldValueElement().find("option").filter((index, valueElement) => jQuery(valueElement).text().toUpperCase() === value);
                                            if (valueElement.length === 0) {
                                                throw new Error("Option is not found in the select dropdown (" + value + ")");
                                            }

                                            getFieldValueElement().val(valueElement.prop("value"));
                                        };
                                        field.clear = () => getFieldValueElement().val("");
                                    } else if (fieldValueElement.is("select.scContentControlMultilistBox")) {
                                        field.getSelectedValueElement = () => getFieldValueElement().children();
                                        field.getSelectedValue = () => getSelectedValueElement().map((index, valueElement) => jQuery(valueElement).prop("value"));
                                        field.getSelectedText = () => getSelectedValueElement().map((index, valueElement) => jQuery(valueElement).text());
                                        field.clear = () => getFieldValueElement().children().trigger("dblclick");
                                    }

                                    return field;
                                }
                            };
                        }
                    };
                },
                searchItemAsync: async (search) => {
                    document.getElementById("TreeSearch").value = search;
                    jQuery("#ContentEditorForm #SearchPanel .scSearchButton").trigger("click");
                    return helper.waitForConditionAsync(() => {
                        const selectedItemId = jQuery("#ContentEditorForm #SearchResult a.scSearchLink:first").data("itemId");
                        const contentFrame = jQuery("#ContentEditorForm #ContentEditor #FContent" + selectedItemId.replace(/[^0-9a-z]/gi, ""));
                        return contentFrame.length === 1;
                    });
                }
            }
        };
    })();`;
}

export async function IsIdentityServerPageAsync(helper) {
    return helper.executeScriptAsync(`document.querySelectorAll(".login-page, .logo-wrap > img[alt='Sitecore logo'], input[id='ReturnUrl'][value*='/connect/authorize/callback?client_id=Sitecore']").length === 3`);
}

export async function IsSitecoreApplicationPageAsync(tabId) {
    const tabInfo = await common.getTabAsync(tabId);
    const url = tabInfo.url.toLowerCase();
    return url.indexOf("/sitecore/") > -1;
}

export async function IsAzureInstanceAsync(tabId) {
    const tabInfo = await common.getTabAsync(tabId);
    const url = tabInfo.url.toLowerCase();
    return url.indexOf(".azurewebsites.net") > -1;
}

export async function IsContentEditorPageAsync(tabId) {
    const tabInfo = await common.getTabAsync(tabId);
    const url = tabInfo.url.toLowerCase();
    return url.indexOf("/sitecore/shell/applications/content%20editor.aspx") > -1;
}

export const LoginToSitecore = new AutomationTask(AutomationType, "Login to Sitecore", async context => {
    if (!await IsIdentityServerPageAsync(context.helper)) {
        const host = await context.helper.getUrlHostAsync();
        const sitecoreUrl = `https://${host}/sitecore/shell/sitecore/client/Applications/Launchpad`;
        context.info("Redirecting to login: " + sitecoreUrl);
        await context.helper.redirectToAsync(sitecoreUrl);
        if (!await IsIdentityServerPageAsync(context.helper)) {
            if (await IsSitecoreApplicationPageAsync(context.tabId)) {
                context.info("You are logged in already");
                context.end(true);
            } else {
                context.error("Unable to load identity server login page");
                context.end(false);
            }
            return;
        }
    }

    let username = context.options.Sitecore.Login.Username;
    let password = context.options.Sitecore.Login.Password;
    if (await IsAzureInstanceAsync(context.tabId)) {
        username = context.options.Sitecore.Login.Azure.Username;
        password = context.options.Sitecore.Login.Azure.Password;
    }

    const success = await context.helper.executeScriptAsync(`
        const usernameInput = document.querySelector("input[name='Username']");
        const passwordInput = document.querySelector("input[name='Password']");
        const loginButton = document.querySelector("button[value='login']");
        if (usernameInput && passwordInput && loginButton) {
            usernameInput.value = "${username}";
            passwordInput.value = "${password}";
            loginButton.click();
            return true;
        }
        return false;
    `);

    await context.helper.waitForDocumentLoaded();

    if (success) {
        context.success("Completed");
    } else {
        context.error("Failed to execute login script");
    }

    context.end(true);
});

export const LaunchInViewMode = new AutomationTask(AutomationType, "Launch in View Mode", async context => {
    const url = await context.helper.executeScriptAsync(`
        let url = document.location.origin;
        const queryString = decodeURIComponent(decodeURIComponent(document.location.search));
        if (queryString.indexOf("/identity/signin") > -1 && queryString.indexOf("&redirect_uri=") > -1) {
            const startIndex = queryString.indexOf("&redirect_uri=") + "&redirect_uri=".length;
            const endIndex = queryString.indexOf("/identity/signin");
            url = queryString.substring(startIndex, endIndex);
        }
        return url;
    `)
    if (url && url.indexOf("http") === 0) {
        context.info("Redirecting to " + url);
        await context.helper.redirectToAsync(url + "?sc_lang=en&sc_mode=normal&sc_debug=0&sc_trace=0&sc_prof=0&sc_ri=0&sc_rb=0&sc_expview=0");
        context.end(true);
    } else {
        context.error("Unable to get the site URL");
        context.end(false);
    }
})

export const LaunchContentEditor = new AutomationTask(AutomationType, "Launch Content Editor", async context => {
    if (await IsContentEditorPageAsync(context.tabId)) {
        context.info("Content Editor is already loaded");
        context.end(true);
        return;
    }

    await context.executeSubtaskAsync(LoginToSitecore, true);
    const host = await context.helper.getUrlHostAsync();
    const contentEditorUrl = `https://${host}/sitecore/shell/Applications/Content%20Editor.aspx?sc_bw=1`;
    await context.helper.redirectToAsync(contentEditorUrl);
    context.end(true);
});

export const SwitchOffResourceOptimiser = new AutomationTask(AutomationType, "Switch off scripts and styles optimiser", async context => {
    await context.executeSubtaskAsync(LaunchContentEditor, true);
    await context.helper.executeScriptAsync(`
        // set mode to disabled for Scripts
        await scHelper.contentEditor.searchItemAsync("/sitecore/system/Settings/Foundation/Experience Accelerator/Theming/Optimiser/Scripts");
        (await (await scHelper.contentEditor.getContentTabAsync()).getSectionAsync("Settings")).getField("Mode").setSelectedText("Disabled");
        await scHelper.contentEditor.ribbon.getTab("Home").getButton("Save").clickAsync();

        // set mode to disabled for Styles
        await scHelper.contentEditor.searchItemAsync("/sitecore/system/Settings/Foundation/Experience Accelerator/Theming/Optimiser/Styles");
        (await (await scHelper.contentEditor.getContentTabAsync()).getSectionAsync("Settings")).getField("Mode").setSelectedText("Disabled");
        await scHelper.contentEditor.ribbon.getTab("Home").getButton("Save").clickAsync();

        // publish incremental
        await (await scHelper.contentEditor.ribbon.getTab("Publish").getButton("Publish").expandAsync()).getButton("Publish site").clickAsync();
        await scHelper.waitForAjaxAsync();
        await scHelper.waitForPopupAsync();
    `, { helpers: [HelperFunctions, ScHelperFunctions] });
    if (await context.helper.checkFrameExistAsync("/sitecore/shell/Applications/Publish.aspx")) {
        await context.helper.executeScriptAsync(`
            jQuery("#IncrementalPublish").trigger("click");
            const englishLanguage = jQuery("#Languages").find("input").filter((index, language) => language.nextElementSibling.innerText === "English");
            if (englishLanguage.is(":checked") === false) {
                englishLanguage.trigger("click");
            }
            jQuery("#NextButton").trigger("click");
        `, { frameId: "/sitecore/shell/Applications/Publish.aspx" });
    } else {
        context.error("Failed to open the publish popup");
    }
    context.end(true);
});

export async function GetSitecoreApplicationAutomations(tabId) {
    const automations = [LaunchInViewMode];

    if (!(await IsContentEditorPageAsync(tabId))) {
        automations.push(LaunchContentEditor);
    }

    automations.push(SwitchOffResourceOptimiser);

    automations.push(new AutomationTask("Test", "Debug", async context => {
        globalThis.helper = context.helper;
        await context.helper.executeScriptAsync(`
            window.helper = helper;
            window.scHelper = scHelper;
        `, { helpers: [HelperFunctions, ScHelperFunctions] });
        context.end(true);
    }));

    return automations;
}

export function GetSitecoreIdentityServerAutomations(tabId) {
    return [LoginToSitecore, LaunchInViewMode];
}