"use strict";

import PageEvent, { PageEventType, PageEventStatus, PageEventIcon } from "../modules/PageEvent.js";
import PageHelper from "../helpers/PageHelper.js";

export class Build {
    static IsBuildPage() {
        return PageHelper.urlContains("_build/index") && PageHelper.queryContains("buildId=");
    }

    static DetectBuildEvent(callback) {
        const checkElement = PageHelper.getElement(".plan-tree").children().first();
        if (checkElement.hasClass("bowtie-play-fill")) {
            callback(new PageEvent(PageEventType.Build, PageHelper.getQuery("buildId").toString()));
        }
    }

    static CheckBuildEventProgress(pageEvent) {
        const checkElement = PageHelper.getElement(".plan-tree").children().first();
        if (checkElement.hasClass("bowtie-check")) {
            pageEvent.icon = PageEventIcon.Success;
            pageEvent.complete(PageEventStatus.BuildSuccess);
        } else if (checkElement.hasClass("bowtie-edit-delete")) {
            pageEvent.icon = PageEventIcon.Fail;
            pageEvent.complete(PageEventStatus.BuildFailed);
        } else if (checkElement.hasClass("bowtie-status-stop-outline")) {
            pageEvent.icon = PageEventIcon.Fail;
            pageEvent.complete(PageEventStatus.BuildCanceled);
        }
    }
}
