"use strict";

import * as currentModule from "./contentScript.js";
import * as common from "./common.js";
import * as TFS from "./features/TFS.js";
import PageEvent, { PageEventType } from "./modules/PageEvent.js";
import StateHandler from "./modules/StateHandler.js";

export const name = "contentScript";

export const state = {
	tabId: null,
	focused: false,
	listeningToEvents: false,
	listeningToProgress: false,
	checkEventsTimeout: 1000,
	checkProgressTimeout: 5000
};

const WindowMessageState = new StateHandler();

export function checkForProgress() {
	common.setEvents(common.getEvents(e => e.completed === false));

	if (common.getEvents().length > 0) {
		const currentEvents = common.getEvents();
		for (const currentEvent of currentEvents) {
			checkEvent(currentEvent, true);
		}

		globalThis.setTimeout(currentModule.checkForProgress, currentModule.state.checkProgressTimeout);
	} else {
		currentModule.state.listeningToProgress = false;
	}
}

function listenToProgress() {
	if (currentModule.state.listeningToProgress === true) {
		return;
	}
	currentModule.state.listeningToProgress = true;
	currentModule.checkForProgress();
}

function checkEvent(pageEvent, checkProgress) {
	switch (pageEvent.type) {
		case PageEventType.Build:
			if (TFS.Build.IsBuildPage()) {
				if (!checkProgress) {
					TFS.Build.DetectBuildEvent(newEvent => {
						newEvent.tabId = currentModule.state.tabId;
						common.addEvent(newEvent);
						common.sendMessageAsync({
							currentEvent: newEvent
						});
					});
				}
				if (checkProgress) {
					TFS.Build.CheckBuildEventProgress(pageEvent);
					if (pageEvent.completed) {
						// trigger notification
						common.sendMessageAsync({
							currentEvent: pageEvent,
							command: "sendNotification",
							arguments: [
								{
									icon: pageEvent.icon,
									title: pageEvent.getTitle(),
									message: pageEvent.getStatusMessage(),
									click: "focusTab",
									persist: true,
									tabId: currentModule.state.tabId
								}
							]
						});
					}
				}
			}
			break;
		default:
			break;
	}
}

export function checkForEvents() {
	currentModule.state.focused = common.isDocumentFocused();

	checkEvent(new PageEvent(PageEventType.Build), false);
	if (common.state.currentEvents.length > 0) {
		listenToProgress();
	}

	if (currentModule.state.focused === true) {
		globalThis.setTimeout(currentModule.checkForEvents, currentModule.state.checkEventsTimeout);
	} else {
		currentModule.state.listeningToEvents = false;
	}
}

function listenToEvents() {
	if (currentModule.state.listeningToEvents === true) {
		return;
	}
	currentModule.state.listeningToEvents = true;
	currentModule.checkForEvents();
}

function escapeCode(code) {
    return code.replace(/"/g, "\\\"");
}

async function executeInPageAsync(code) {
	return new Promise(resolve => {
		const singleLineCode = code.indexOf("\n") === -1 && code.indexOf("return " !== 0);
		const id = common.guid();
		const scriptTag = globalThis.document.createElement('script');
		const script = `(async () => {
			let error;
			const result = await (async () => {
				try {
					${singleLineCode ? "return " + code + ";" : code}
				} catch (e) {
					error = e.message;
				}
				return null;
			})();
			console.log("Script injection ${common.state.currentPage} ${id} ${singleLineCode ? `\\n${escapeCode(code)}\\n` : ""}", result);
			const message = {
				id: "${id}",
				result: JSON.stringify(result),
				error: error
			}
			globalThis.window.postMessage(message, "*");
		})();`;
		const scriptBody = globalThis.document.createTextNode(script);
		scriptTag.appendChild(scriptBody);

		WindowMessageState.update({
			id: id,
			resolve: resolve,
			scriptTag: scriptTag
		});
		
		globalThis.document.body.append(scriptTag);
	});
}

function onWindowMessage(event) {
	if (event.source.top !== globalThis.window.top) {
		return;
	}

	const messageHandler = WindowMessageState.get(event.data.id);
	if (messageHandler) {
		WindowMessageState.remove(event.data.id);
		messageHandler.scriptTag.remove();
		if (event.data.error) {
			common.error("Script error: " + event.data.error);
		}
		messageHandler.resolve(JSON.parse(event.data.result));
	} else {
		common.sendMessageAsync({
			windowMessage: event.data
		});
	}
}

function initializeEventListener(options, locationHref) {
	if (options.Common.Url) {
		const urlPattern = new RegExp(options.Common.Url, "i");
		if (urlPattern.test(locationHref)) {
			common.log("Listening to page events");
			listenToEvents();
			globalThis.setTimeout(listenToEvents, 5000);
			globalThis.window.addEventListener("focus", listenToEvents);
		}
	}
}

async function registerPageAsync(pageState) {
	const promise = common.sendMessageAsync({
		scope: "tab",
		command: "update",
		arguments: [pageState]
	});

	if (pageState.isSitecoreApplication) {
		common.log("Registered tab as Sitecore application instance");
	}

	if (pageState.isSitecoreIdentityServer) {
		common.log("Registered tab as Sitecore Identity Server instance");
	}

	if (pageState.isCommerceApplication) {
		common.log("Registered tab as Commerce application instance");
	}

	return promise;
}

async function initializePageRegistrationAsync(locationHref) {
	executeInPageAsync(`
		window.windowUnloading = false;
		window.addEventListener("beforeunload", () => window.windowUnloading = true);
	`);

	const isSitecoreApplication = /\/sitecore\//i.test(locationHref);
	const isSitecoreIdentityServer = /\/account\/login/i.test(locationHref);
	const isCommerceApplication = await executeInPageAsync(`window.hasOwnProperty("CXAApplication")`);

	return registerPageAsync({
		id: currentModule.state.tabId,
		isSitecoreApplication: isSitecoreApplication,
		isSitecoreIdentityServer: isSitecoreIdentityServer,
		isCommerceApplication: isCommerceApplication
	});
}

export async function initializeAsync() {
	common.state.currentPage = currentModule.name;

	if (!common.isDocumentReady()) {
		globalThis.window.addEventListener("load", initializeAsync);
	} else {
		globalThis.window.addEventListener("message", onWindowMessage, false);

		const tabId = await common.sendMessageAsync({ scope: "sender", command: "tab.id" });
		currentModule.state.tabId = tabId;

		const option = await common.getOptionsAsync();
		const locationHref = common.getDocumentLocation().href;
		initializeEventListener(option, locationHref);
		initializePageRegistrationAsync(locationHref);
	}
}

globalThis.debugScript = () => {
    console.log("debug");
};