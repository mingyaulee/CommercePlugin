"use strict";

import * as currentModule from "./common.js";
import DefaultOption from "./DefaultOption.js";
import Option from "./modules/Option.js";

export const name = "common";

export const state = {
	currentEvents: [],
	currentPage: "",
	badgeText: null
}

const emptyPromise = new Promise(() => {});

// Browser Extension Helpers

	const getFinalOptionObj = (optionObj, defaultOptionObj) => {
		const finalOptionObj = {};
		for (const optionKey in defaultOptionObj) {
			if (optionObj.hasOwnProperty(optionKey) === false) {
				finalOptionObj[optionKey] = defaultOptionObj[optionKey];
			} else {
				finalOptionObj[optionKey] = optionObj[optionKey];
				if (typeof(finalOptionObj[optionKey]) === "object") {
					finalOptionObj[optionKey] = getFinalOptionObj(optionObj[optionKey], defaultOptionObj[optionKey]);
				}
			}
		}
		return finalOptionObj;
	};

    export function getOptionsAsync() {
		if (globalThis.chrome) {
			return new Promise(resolve => {
				globalThis.chrome.storage.sync.get(optionObj => {
					if (!optionObj) {
						optionObj = {};
					}
					const finalOptionObj = getFinalOptionObj(optionObj, DefaultOption);
					resolve(new Option(finalOptionObj));
				});
			});
		}
		return globalThis.browser.storage.sync.get(key || null)
			.then(optionObj => {
				if (!optionObj) {
					optionObj = {};
				}
				const finalOptionObj = getFinalOptionObj(optionObj, DefaultOption);
				return new Option(finalOptionObj);
			});	
	}

    export function goToOptionsPage() {
		if (globalThis.browser.runtime.openOptionsPage) {
			globalThis.browser.runtime.openOptionsPage();
		} else {
			globalThis.window.open(globalThis.browser.runtime.getURL("Views/options.html"));
		}
	}

	/**
	 * Activates the tab
	 * @param {number|string} tabId the tab id
	 */
	export function switchToTabAsync(tabId) {
		if (!tabId) {
			return emptyPromise;
		}

		if (currentModule.state.currentPage === "background") {
			if (tabId.constructor === String) {
				tabId = parseInt(tabId);
			}
			return globalThis.browser.tabs.get(tabId)
				.then(tab => globalThis.browser.windows.update(tab.windowId, { focused: true }))
				.then(() => globalThis.browser.tabs.update(tabId, { active: true }))
				.catch(() => {});
		} else {
			return currentModule.sendMessageAsync({ scope: currentModule.name, command: currentModule.switchToTabAsync.name, arguments: [ tabId ] });
		}
	}
	
	export function redirectTabToUrlAsync(tabId, url) {
		return globalThis.browser.tabs.update(tabId, { url: url });
	}

	export function getTabAsync(tabId) {
		return globalThis.browser.tabs.get(tabId);
	}

	export function getActiveTabAsync() {
		return globalThis.browser.tabs.query({ active: true, currentWindow: true })
			.then(tabs => tabs[0].id);
	}

	export function sendMessageAsync(message) {
		return new Promise((resolve, reject) => {
			try {
				globalThis.browser.runtime.sendMessage(message)
					.then(resolve);
			} catch (error) {
				reject(error);
			}
		});
	}

	export function setBadgeText(text, tabId) {
		var newBadgeText = text || (currentModule.state.currentEvents.length || "").toString();
		if (currentModule.state.badgeText !== newBadgeText) {
			currentModule.state.badgeText = newBadgeText;
			globalThis.browser.browserAction.setBadgeText({
                text: newBadgeText,
                tabId: tabId
			});
		}
	}

// Utils

	export function waitFor(timeMs) {
		return new Promise(resolve => {
			setTimeout(resolve, timeMs);
		});
	}

	export function isDocumentReady() {
		return globalThis.document.readyState === "complete";
	}

	export function isDocumentFocused() {
		return !globalThis.document.hidden;
	}

	export function getDocumentLocation() {
		return globalThis.document.location;
	}

	export function log(msg) {
		if (msg !== null && msg !== undefined && msg.constructor === String) {
			globalThis.console.log("%c" + msg, "color: #2980b9");
		} else {
			globalThis.console.log(msg);
		}
	}

	export function error(msg) {
		if (msg !== null && msg !== undefined && msg.constructor === String) {
			globalThis.console.log("%c" + msg, "color: #d83939");
		} else {
			globalThis.console.error(msg);
		}
	}

	export function guid() {
		return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
			const r = globalThis.Math.random() * 16 | 0, v = c == "x" ? r : (r & 0x3 | 0x8);
			return v.toString(16);
		});
	}

// Events

	export function getEvents(filter) {
		if (filter) {
			return currentModule.state.currentEvents.filter(filter);
		}
		return currentModule.state.currentEvents;
	}

	export function setEvents(events, converter) {
		currentModule.state.currentEvents = converter instanceof Function ? events.map(x => converter(x)) : events;
	}

	export function addEvent(evt) {
		const existingEvents = currentModule.getEvents(e => e.equals(evt));
		if (existingEvents.length === 0) {
			currentModule.state.currentEvents.push(evt);
		} else {
			currentModule.setEvents(currentModule.state.currentEvents.map(x => x === existingEvents[0] ? evt : x));
		}
	}

	export function removeEventsForTab(tabId) {
		if (currentModule.getEvents(x => x.tabId === tabId).length !== 0) {
			currentModule.setEvents(currentModule.state.currentEvents.filter(x => x.tabId !== tabId));
		}
	}

// DOM Helpers

	export function addElementOnClick(elementId, onClick) {
		const element = globalThis.document.getElementById(elementId);
		if (element) {
			element.addEventListener("click", onClick);
		}
	}