"use strict";

import * as common from "../common.js";
import QueryString, { ValueCollection } from "../modules/QueryString.js";
import PageElement from "../modules/PageElement.js";

export default class PageHelper {
	/**
	 * Gets element in document
	 * @param {String} query the query selector
	 * @returns {PageElement} the page element matching the selector
	 */
	static getElement(query) { return new PageElement(globalThis.document.querySelectorAll(query)); }

	/**
	 * Checks if the document URL contains the string provided
	 * @param {String} str the string to check in URL
	 * @returns {Boolean} boolean
	 */
	static urlContains(str) { return common.getDocumentLocation().href.toLowerCase().indexOf(str.toLowerCase()) > -1; }

	/**
	 * Checks if the query string contains the string provided
	 * @param {String} str the string to check in the URL query
	 * @returns {Boolean} boolean
	 */
	static queryContains(str) { return common.getDocumentLocation().search.toLowerCase().indexOf(str.toLowerCase()) > -1; }

	/**
	 * Gets the key-value dictionary of the URL query, or get the dictionary value when the optional parameter `key` is provided
	 * @param {String} [key] the key to retrieve from URL query, if provided returns ValueCollection
	 * @returns {QueryString|ValueCollection} QueryString object or ValueCollection for the key provided
	 */
	static getQuery(key) {
		const queryString = common.getDocumentLocation().search.substring(1);
		const dict = QueryString.Parse(queryString);		
		if (key === undefined) {
			return dict;
		}
		return dict[key];
	}
}

