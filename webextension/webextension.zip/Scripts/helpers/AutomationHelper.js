"use strict";

import * as common from "../common.js";
import StateHandler from "../modules/StateHandler.js";

/**
 * Execute option object
 * @typedef {Object} ExecuteOption
 * @property {String} code code to execute
 * @property {String} frameId "#frameId" or "/frame/url"
 * @property {Function[]} helpers array of helper functions
 */

/**
 * Wait option object
 * @typedef {Object} WaitOption
 * @property {Number} pollMs frequency of polling
 * @property {Number} timeoutMs timeout period
 * @property {Number} delayMs delay period
 */

const WindowMessageState = new StateHandler();

function handleWindowMessage(message) {
    const messageHandler = WindowMessageState.get(message.id);
    if (messageHandler) {
        if (messageHandler.frameId !== message.frameId) {
            return;
        }

        WindowMessageState.remove(message.id);
        if (message.error) {
            common.error("Automation script error: " + message.error);
        }
        messageHandler.resolve(typeof (message.result) === "string" ? JSON.parse(message.result) : message.result);
    }
}

function escapeCode(code) {
    return code.replace(/\`/g, "\\`").replace(/\\/g, "\\\\").replace(/\$\{/g, "\\${");
}

/**
 * Helper function for script injection
 */
export function HelperFunctions() {
    return `const helper = (function () {
        const waitForConditionAsync = async (condition, waitOption = { pollMs: 1000, timeoutMs: 10000, delayMs: 0 }) => {
            return new Promise((resolve, reject) => {
                const startTime = new Date().getTime();
                const maxEndTime = startTime + waitOption.timeoutMs || 10000;
                const checkCondition = async () => {
                    const result = condition();
                    if (!result) {
                        if (new Date().getTime() < maxEndTime) {
                            setTimeout(checkCondition, waitOption.pollMs || 1000);
                        } else {
                            reject("Condition is not true after timeout (\${condition.toString()})");
                        }
                    } else {
                        resolve();
                    }
                };
                if (waitOption.delayMs) {
                    setTimeout(checkCondition, waitOption.delayMs);
                } else {
                    checkCondition();
                }
            });
        };
        return {
            waitForAjaxAsync: () => waitForConditionAsync(() => {
                let ajaxCount = 0;
                if (window.jQuery) {
                    ajaxCount += window.jQuery.active;
                }
                return ajaxCount === 0;
            }, { delayMs: 500 }),
            waitForConditionAsync: waitForConditionAsync
        }
    })();`;
}

export default class AutomationHelper {
    tabId;

    /**
     * Creates a new automation helper object
     * @param {Number} tabId tab id
     */
    constructor(tabId) {
        this.tabId = tabId;
        this.setupMessageListener();
    }

    /**
     * Executes the code block in tab
     * @param {String} code code to execute
     * @param {ExecuteOption} executeOption execute option
     */
    async executeScriptAsync(code, executeOption = {}) {
        return this.executeAsync({ ...executeOption, code: code });
    }

    /**
     * Execute in tab with the option
     * @param {ExecuteOption} executeOption execute option
     */
    async executeAsync(executeOption) {
        return new Promise(resolve => {
            const frameId = executeOption.frameId || "";
            if (executeOption.frameId) {
                delete executeOption.frameId;
                executeOption.allFrames = true;
            }

            const helpers = executeOption.helpers || [];
            if (executeOption.helpers) {
                delete executeOption.helpers;
            }

            const singleLineCode = executeOption.code.indexOf("\n") === -1 && executeOption.code.indexOf("return ") !== 0;
            const id = common.guid();

            executeOption.code = `(function () {
                const frameId = "${frameId.toLowerCase()}";
                if (frameId) {
                    const currentFrameId = window.frameElement ? "#" + window.frameElement.id.toLowerCase() : window.name ? "#" + window.name.toLowerCase() : "";
                    const currentFrameSrc = window.frameElement ? window.frameElement.src.toLowerCase() : "";
                    if (currentFrameId !== frameId && currentFrameSrc.indexOf(frameId) === -1) {
                        return;
                    }
                }

                const scriptTag = document.createElement('script');
                const script = \`(async function () {
                    ${helpers.map(h => escapeCode(h())).join("\\n")}
                    let $error;
                    const $result = await (async () => {
                        try {
                            ${escapeCode(singleLineCode ? "return " + executeOption.code + ";" : executeOption.code)}
                        } catch (e) {
                            $error = e.message;
                        }
                        return null;
                    })();
                    console.log("Script injection ${common.state.currentPage} ${id} ${escapeCode(singleLineCode ? `\\n${executeOption.code.replace(/\"/g, `\\"`)}\\n` : "")}", $result);
                    const message = {
                        id: "${id}",
                        tabId: ${this.tabId},
                        frameId: "${frameId}",
                        topWindow: window.top === window,
                        result: JSON.stringify($result),
                        error: $error
                    };
                    const postMessage = () => {
                        if ((window.top === window || window.frameElement !== null) && window.top.windowUnloading === undefined) {
                            // if (this is the current window or the frame has access to parent window) and the content script is not injected yet
                            setTimeout(postMessage, 500);
                            return;
                        }
                        window.top.postMessage(message, "*");
                    };
                    postMessage();
                })();\`;
                const scriptBody = document.createTextNode(script);
                scriptTag.appendChild(scriptBody);
                document.body.append(scriptTag);
            })();`;

            WindowMessageState.update({
                id: id,
                frameId: frameId,
                resolve: resolve
            });

            const executeScriptInTab = async () => {
                try {
                    await globalThis.browser.tabs.executeScript(this.tabId, executeOption);
                } catch (error) {
                    if (error.message === "The tab was closed.") {
                        // the tab is redirecting to another page
                        setTimeout(executeScriptInTab, 500);
                    } else {
                        throw error;
                    }
                }
            };

            executeScriptInTab();
        });
    }

    /**
     * Gets the full URL (origin/search#hash)
     */
    async getFullUrlAsync() {
        return this.executeScriptAsync(`document.location.href`);
    }

    /**
     * Gets the host of the URL (localhost:port)
     */
    async getUrlHostAsync() {
        return this.executeScriptAsync(`document.location.host`);
    }

    /**
     * Checks if the url contains the input string
     * @param {String} str input
     */
    async urlContainsAsync(str) {
        return this.executeScriptAsync(`document.location.href.toLowerCase().indexOf("${str}".toLowerCase()) > -1`);
    }

    /**
     * Redirects the tab to the provided url
     * @param {String} url url to redirect to
     */
    async redirectToAsync(url) {
        await common.redirectTabToUrlAsync(this.tabId, url);
        const tabInfo = await common.getTabAsync(this.tabId);
        if (tabInfo.title === "Privacy error") {
            await common.waitFor(500);
        }
        return this.waitForDocumentLoaded();
    }

    /**
     * Checks if frame exists in tab
     * @param {String} frameId "#frameId" or "/frame/url"
     */
    async checkFrameExistAsync(frameId) {
        return new Promise(resolve => {
            let responseReceived = false;
            this.executeScriptAsync(`true`, { frameId: frameId }).then(() => {
                responseReceived = true;
                resolve(true);
            });
            setTimeout(() => {
                if (responseReceived === false) {
                    resolve(false);
                }
            }, 1000);
        });
        
    }

    /**
     * Wait for document load to be completed
     */
    async waitForDocumentLoaded() {
        return this.waitForConditionAsync(`document.readyState === "complete" && window.windowUnloading === false`, { timeoutMs: 30000, delayMs: 1000 });
    }

    /**
     * 
     * @param {String} condition condition to execute in tab
     * @param {WaitOption} waitOption wait option
     * @param {ExecuteOption} executeOption execute option
     */
    async waitForConditionAsync(condition, waitOption = { pollMs: 1000, timeoutMs: 10000, delayMs: 0 }, executeOption = {}) {
        return new Promise((resolve, reject) => {
            const startTime = new Date().getTime();
            const maxEndTime = startTime + waitOption.timeoutMs || 10000;
            const checkCondition = async () => {
                let result = false;
                try {
                    result = await this.executeScriptAsync(condition, executeOption);
                } catch {}
                if (!result) {
                    if (new Date().getTime() < maxEndTime) {
                        setTimeout(checkCondition, waitOption.pollMs || 1000);
                    } else {
                        reject(`Condition is not true after timeout ("${condition}")`);
                    }
                } else {
                    resolve();
                }
            };
            if (waitOption.delayMs) {
                setTimeout(checkCondition, waitOption.delayMs);
            } else {
                checkCondition();
            }
        });
    }

    setupMessageListener() {
        const messageListener = (request, sender, sendResponse) => {
            if (request.windowMessage) {
                if (request.windowMessage.tabId !== this.tabId) {
                    return;
                }

                handleWindowMessage(request.windowMessage);
            }
        };

        globalThis.browser.runtime.onMessage.addListener(messageListener);
    }
}

