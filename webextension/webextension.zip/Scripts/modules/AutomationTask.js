"use strict";

import AutomationHelper from "../helpers/AutomationHelper.js";

/**
 * @callback ExecuteTaskFunction
 * @param {AutomationContext} context the automation context
 * @returns {Void}
 */

/**
 * @callback GenericLoggerFunction
 * @param {String} type log type
 * @param {String} message log message
 * @returns {Void}
 */

/**
 * @callback LoggerFunction
 * @param {String} message log message
 * @returns {Void}
 */

/**
 * @callback EndTaskFunction
 * @param {Boolean} success
 * @returns {Void}
 */

/**
 * @callback ExecuteSubtackFunction
 * @param {AutomationTask} task task to execute
 * @param {Boolean} suppressLog suppress log from task
 * @returns {Void}
 */

  export default class AutomationTask {
    /**
     * Gets the type of the automation task
     * @type {String}
     */
    type;

    /**
     * Gets the name of the automation task
     * @type {String}
     */
    name;

    /**
     * Gets the task to execute
     * @type {ExecuteTaskFunction}
     */
    executeTask;

    /**
     * Creates a new automation task
     * @param {String} type Type of task
     * @param {String} name Name of task
     * @param {ExecuteTaskFunction} executeTaskFunction Task to execute
     */
    constructor(type, name, executeTaskFunction) {
        this.type = type;
        this.name = name;
        this.executeTask = executeTaskFunction;
    }

    /**
     * Executes the automation task
     * @param {Number} tabId current tab id
     * @param {Object} options automation options
     * @param {GenericLoggerFunction} logger logger
     */
    executeAsync(tabId, options, logger) {
        return new Promise(resolve => {
            const startTaskFunc = async (context) => {
                context.info(`Task ${this.name} started`);
                try {
                    await this.executeTask(context);
                } catch (error) {
                    context.error(`Task ${this.name} ended with error`, error);
                    context.end(false);
                }
            };
            const endTaskFunc = (context, success) => {
                context.info(`Task ${this.name} ended`);
                resolve(success);
            };
            const executeSubtaskFunc = (context, subtask, suppressLog) => {
                return new Promise(resolveSubtask => {
                    const startSubtaskFunc = async (subtaskContext) => {
                        context.info(`Subtask ${subtask.name} started`);
                        try {
                            await subtask.executeTask(subtaskContext);
                        } catch (error) {
                            context.error(`Subtask ${subtask.name} ended with error`, error);
                            subtaskContext.end(false);
                        }    
                    };
                    const endSubtaskFunc = (subtaskContext, success) => {
                        context.info(`Subtask ${subtask.name} ended`);
                        resolveSubtask(success);
                    };
                    const subtaskContext = new AutomationContext(context.tabId, context.options, context.logger, endSubtaskFunc, executeSubtaskFunc);
                    if (suppressLog) {
                        subtaskContext.info = subtaskContext.success = subtaskContext.error = () => { };
                    }
                    startSubtaskFunc(subtaskContext);
                });
            };
            const context = new AutomationContext(tabId, options, logger, endTaskFunc, executeSubtaskFunc);
            startTaskFunc(context);
        });
    }
}

class AutomationContext {
    /**
     * Gets the automation helper
     * @type {AutomationHelper}
     */
    helper;

    /**
     * Gets the current tab id
     * @type {Number}
     */
    tabId;

    /**
     * Gets the options
     * @type {Object}
     */
    options;

    /**
     * Gets the generic logger
     * @type {GenericLoggerFunction}
     */
    logger;

    /**
     * Log message as info type
     * @type {LoggerFunction}
     */
    info;

    /**
     * Log message as success type
     * @type {LoggerFunction}
     */
    success;

    /**
     * Log message as error type
     * @type {LoggerFunction}
     */
    error;

    /**
     * Ends the current task
     * @type {EndTaskFunction}
     */
    end;

    /**
     * Execute subtask
     * @type {ExecuteSubtackFunction}
     * @function
     * @param {String} test
     */
    executeSubtaskAsync;

    /**
     * 
     * @param {Number} tabId current tab id
     * @param {Object} options automation options
     * @param {GenericLoggerFunction} logger generic logger
     * @param {function(AutomationContext, Boolean)} endFunc callback to end the current task
     * @param {function(AutomationContext, AutomationTask, Boolean)} executeSubtaskFunc callback to execute a subtask
     */
    constructor(tabId, options, logger, endFunc, executeSubtaskFunc) {
        this.helper = new AutomationHelper(tabId);
        this.tabId = tabId;
        this.options = options;
        this.logger = logger;
        this.info = logger.bind(null, "info");
        this.success = logger.bind(null, "success");
        this.error = logger.bind(null, "danger");
        this.end = endFunc.bind(null, this);
        this.executeSubtaskAsync = executeSubtaskFunc.bind(null, this);
    }
}