"use strict";

const handler = {
	get: (target, property) => {
        if (property in target) {
            return target[property];
        }
        
        const optionObj = target.value[property];
        if (optionObj === null || optionObj === undefined) {
            return null;
        }

        return optionObj.type === String ? optionObj.value : new Option(optionObj);
	}
};

export default class Option {
    type;
    name;
    value;

    constructor(optionObj) {
        this.type = optionObj.type;
        this.name = optionObj.name;
        this.value = optionObj.value;
        return new Proxy(this, handler);
    }
}