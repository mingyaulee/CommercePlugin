"use strict";

function isNullOrUndefined(obj) {
    return obj === undefined || obj === null;
}

function convertNodeListToArray(nodeList) {
    const newElements = [];
    nodeList.forEach(x => newElements.push(x));
    return newElements;
}

export default class PageElement {
    /**
     * Gets the array of elements
     * @type {Element[]}
     */
    elements;

    /**
     * Creates a new page element object
     * @param {(Array|NodeList|Element)} elements The element or elements object
     */
    constructor(elements) {
        if (isNullOrUndefined(elements)) {
            elements = [];
        }

        if (!(elements instanceof Array)) {
            if (elements instanceof NodeList) {
                elements = convertNodeListToArray(elements);
            } else {
                elements = [elements];
            }
        }
        
        this.elements = elements;
    }

    /**
     * Gets the count of elements
     * @returns {Number} length
     */
    get length() {
        return this.elements ? this.elements.length : 0;
    }

    /**
     * Gets the first element
     * @returns {PageElement} element
     */
    first() { return this.get(0); }

    /**
     * Gets the last element
     * @returns {PageElement} element
     */
    last() { return this.get(this.elements.length - 1); }

    /**
     * Gets the nth element
     * @param {Number} index
     * @returns {PageElement} element
     */
    get(i) { return new PageElement(i >= 0 && i < this.elements.length ? this.elements[i] : null); }

    /**
     * Checks if at least one element matches the condition
     * @param {Function} condition function to match
     * @returns {Boolean} boolean
     */
    any(condition) {
        return this.elements.some(condition);
    }

    /**
     * Gets the children for this element
     * @returns {PageElement} element
     */
    children() {
        const children = [];
        this.elements.forEach(x => {
            for (const child of x.children) {
                children.push(child);
            }
        });
        return new PageElement(children);
    }

    /**
     * Checks if the element has the class name provided
     * @param {String} cls class name
     * @returns {Boolean} boolean
     */
    hasClass(cls) { return this.any(x => x.classList.contains(cls)); }
}