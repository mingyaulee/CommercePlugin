"use strict";

/**
 * Enum for page event types
 * @readonly
 * @enum {String}
 */
export const PageEventType = {
	Build: "build"
};

/**
 * Enum for page event results
 * @readonly
 * @enum {String}
 */
export const PageEventStatus = {
	BuildSuccess: "Completed",
	BuildFailed: "Failed",
	BuildCanceled: "Canceled"
}

/**
 * Enum for page event icons
 * @readonly
 * @enum {String}
 */
export const PageEventIcon = {
    Success: "success",
    Fail: "fail"
}

export default class PageEvent {
    /**
     * Gets the page event type
     * @type {PageEventType}
     */
    type;

    /**
     * Gets the page event id
     * @type {String|Number}
     */
    id;

    /**
     * Gets the completed state of the page event
     * @type {Boolean}
     */
    completed;

    /**
     * Gets the status of the page event
     * @type {?PageEventStatus}
     */
    status;

    /**
     * Gets the status message of the page event
     * @type {?String}
     */
    statusMessage;

    /**
     * Gets the icon of the page event
     * @type {?PageEventIcon}
     */
    icon;

    /**
     * Gets the progress of the page event
     * @type {?Number}
     */
    progress;

    /**
     * Gets the tab id of the page event
     * @type {?Number}
     */
    tabId;

    /**
     * Creates a new page event
     * @param {PageEventType} type Page event type, use `PageEventType`
     * @param {string|number} id Page event id
     */
    constructor(type, id) {
        this.type = type;
        this.id = id;
        this.completed = false;
        this.status = null;
        this.statusMessage = null;
        this.icon = null;
        this.progress = null;
        this.tabId = null;
    }

    /**
     * Creates a new PageEvent object from an object
     * @param {Object} obj object to create from
     * @returns {PageEvent} new PageEvent object
     */
    static fromObj(obj) {
		let evt = new PageEvent();
		for (const i in obj) {
			if (evt.hasOwnProperty(i)) {
				evt[i] = obj[i];
			}
		}
		return evt;
	}
    
    /**
     * Compares if two PageEvent is equal
     * @param {PageEvent} e object to compare to
     * @returns {Boolean} boolean
     */
    equals(e) { return this.type === e.type && this.id === e.id; }
    
    /**
     * Sets the page event to complete with the provided status
     * @param {PageEventStatus} status the status for completion
     */
    complete(status) {
        this.status = status;
        this.completed = true;
    };
    
    /**
     * Gets the title of the page event
     * @returns {String} the title
     */
    getTitle() {
        switch (this.type) {
            case PageEventType.Build:
                return "Build " + this.id;
            default:
                return "";
        }
    }
    
    /**
     * Gets the status message of the page event
     * @returns {String} the status message
     */
    getStatusMessage() {
        switch (this.type) {
            case PageEventType.Build:
                return this.status;
            default:
                return "";
        }
    }
}
