"use strict";

import * as currentModule from "./background.js";
import * as common from "./common.js";
import * as Sitecore from "./features/Sitecore.js";
import StateHandler from "./modules/StateHandler.js";
import PageEvent from "./modules/PageEvent.js";

export const name = "background";

export const state = {
    options: {},
    notificationTimeout: 5000
};

const NotificationState = new StateHandler({ click: null, tabId: 0, timeout: 0 });
const TabState = new StateHandler({ invalidCert: false, autoBypassInvalidCert: false, isRunningAutomationTask: false, isSitecoreApplication: false, isSitecoreIdentityServer: false, isCommerceApplication: false });

export async function loadOptionsAsync() {
    currentModule.state.options = await common.getOptionsAsync();
}

export function sendNotification(notificationOption) {
    const notificationId = notificationOption.id || common.guid();
    const notification = {
        iconUrl: "../Icons/icon" + (notificationOption.icon ? "-" + notificationOption.icon : "") + ".png",
        type: "basic",
        title: notificationOption.title || "Commerce Plugin",
        message: notificationOption.message || "",
        requireInteraction: notificationOption.persist || false
    };

    if (notificationOption.update) {
        globalThis.clearTimeout(NotificationState.get(notificationId).timeout);
        globalThis.chrome.notifications.clear(notificationId, () => {
            globalThis.chrome.notifications.create(notificationId, notification);
        });
    } else {
        globalThis.chrome.notifications.create(notificationId, notification);
    }

    if (notificationOption.click) {
        NotificationState.update({ id: notificationId, click: notificationOption.click, tabId: notificationOption.tabId });
    }

    if (!notificationOption.persist) {
        NotificationState.update({
            id: notificationId,
            timeout: globalThis.setTimeout(() => globalThis.chrome.notifications.clear(notificationId), currentModule.state.notificationTimeout)
        });
    }

    return notificationId;
}

export function onNotificationClick(notificationId) {
    const notification = NotificationState.get(notificationId);
    if (notification.click) {
        switch (notification.click) {
            case "focusTab":
                common.switchToTabAsync(notification.tabId);
                break;
        }
        NotificationState.remove(notificationId);
    }
};

export function bypassCertificateSecurity(tabId) {
    currentModule.sendNotification({
        icon: "info",
        message: "Trying to bypass certificate security"
    });

    common.switchToTabAsync(tabId);
    fetch(currentModule.state.options.nodeServerUrl + "?action=sendKeysToChrome");

    TabState.update({ id: tabId, invalidCert: false, autoBypassInvalidCert: true });
};

export function messageListenerAsync(message, sender) {
    return new Promise(resolve => {
        let responseArg;
        if (message.currentEvent) {
            let pageEvent = PageEvent.fromObj(message.currentEvent);
            common.addEvent(pageEvent);
            currentEventUpdated();
        }

        if (message.command || message.scope) {
            let scope = currentModule;
            if (message.scope === common.name) {
                scope = common;
            } else if (message.scope === "sender") {
                scope = sender;
            } else if (message.scope === "tab") {
                if (message.id) {
                    scope = TabState.get(message.id);
                } else {
                    scope = TabState;
                }
            }

            let target = scope;
            if (message.command) {
                const commands = message.command.split(".");
                for (const command of commands) {
                    if (target) {
                        scope = target;
                        target = target[command];
                    }
                }
            }

            if (target instanceof Function) {
                responseArg = target.apply(scope, message.arguments || []);
            } else if (target) {
                responseArg = target;
            }
        }

        if (responseArg instanceof Promise) {
            responseArg.then(resolve);
        } else {
            resolve(responseArg);
        }
    });
}

function currentEventUpdated() {
    common.setBadgeText();
}

function onTabUpdated(tabId, changeInfo, tab) {
    if (changeInfo.status === "loading") {
        // Tab is redirecting to another URL
        common.removeEventsForTab(tabId);
        currentEventUpdated();
        TabState.update({ id: tabId, invalidCert: false });
    } else if (changeInfo.status === "complete") {
        const tabState = TabState.get(tabId);
        if (tabState.autoBypassInvalidCert || tabState.isRunningAutomationTask) {
            if (tabState.invalidCert) {
                currentModule.bypassCertificateSecurity(tabId);
            } else if (tabState.autoBypassInvalidCert) {
                TabState.update({ id: tabId, autoBypassInvalidCert: false });
            }
        }
    }
};

function onTabRemoved(tabId, removeInfo) {
    common.removeEventsForTab(tabId);
    currentEventUpdated();
    TabState.remove(tabId);
};

function onNavigationError(details) {
    if (details.url.toLowerCase().indexOf("-identityserver") > -1) {
        Sitecore.HandlePageLoadError(details, currentModule);
    }

    if (details.error === "net::ERR_CERT_INVALID") {
        // Certificate invalid error
        const tabId = details.tabId;
        TabState.update({ id: tabId, invalidCert: true });
        common.setBadgeText("__*__", tabId);
    }
};

async function initializeAsync() {
    common.state.currentPage = currentModule.name;

    globalThis.browser.notifications.onClicked.addListener(currentModule.onNotificationClick);
    globalThis.browser.runtime.onMessage.addListener(currentModule.messageListenerAsync);
    globalThis.browser.tabs.onUpdated.addListener(onTabUpdated);
    globalThis.browser.tabs.onRemoved.addListener(onTabRemoved);
    globalThis.browser.webNavigation.onErrorOccurred.addListener(onNavigationError);

    await currentModule.loadOptionsAsync();
    common.setBadgeText();
}

initializeAsync();

globalThis.debugScript = () => {
    console.log("debug");
};